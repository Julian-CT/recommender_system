#!/bin/bash
source /path/to/venv/bin/activate  # Ative o ambiente virtual se necessário
python3 app/app.py &
